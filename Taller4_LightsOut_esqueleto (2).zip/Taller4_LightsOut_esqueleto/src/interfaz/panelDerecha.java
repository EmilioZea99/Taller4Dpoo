package interfaz;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

public class panelDerecha extends JPanel implements ActionListener{
	private Ventana ventana;
	public final static String NUEVO = "NUEVO";
	public final static String REINICIAR = "REINICIAR";
	public final static String TOP10 = "TOP-10";
	public final static String CAMBIAR = "CAMBIAR";
	public JButton Bnuevo;
	public JButton Breiniciar;
	public JButton Btop;
	public JButton Bcambiar;
	public panelDerecha(Ventana ventana)
	{
		
		this.ventana=ventana;
		this.setLayout(new GridLayout(4,1));
		//panelDerecha.setLayout(new BorderLayout());
		Bnuevo=new JButton("NUEVO");
		Bnuevo.setActionCommand( NUEVO );
        Bnuevo.addActionListener( this );
        this.add(Bnuevo);
		
        Breiniciar=new JButton("REINICIAR");
        Breiniciar.setActionCommand(REINICIAR );
        Breiniciar.addActionListener( this );
        this.add(Breiniciar);
        
        
        Btop=new JButton("TOP-10");
        Btop.setActionCommand(TOP10 );
        Btop.addActionListener( this );
        this.add(Btop);
        
        
        Bcambiar=new JButton("CAMBIAR JUGADOR");
        Bcambiar.setActionCommand(CAMBIAR );
        Bcambiar.addActionListener( this );
        this.add(Bcambiar);
		
		
	
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		 String comando = e.getActionCommand( );
		 if (comando.equals(NUEVO))
		 {
			 ventana.nuevoJuego();
		 }
		 else if(comando.equals(REINICIAR))
		 {
			 ventana.reiniciar();
		 }
		 else if(comando.equals(TOP10))
		 {
			 
		 }
		 else if(comando.equals(CAMBIAR))
		 {
			 
		}
	}
	
	
	
	

}