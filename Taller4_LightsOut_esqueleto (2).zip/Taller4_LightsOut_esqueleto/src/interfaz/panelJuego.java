package interfaz;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import uniandes.dpoo.taller4.modelo.Tablero;

public class panelJuego extends JPanel implements MouseListener
{
	private Tablero tablero;
	private Ventana ventana;
	private int tamanio;
	public final static String RUTA_IMAGEN1 = "./data/luz.png";
	public final static String RUTA_IMAGEN2 = "./data/download.png";
	private BufferedImage imagen1;
	private BufferedImage imagen2;
	private int fila;
	private int col;
	private boolean terminar;
	private int puntaje;
	
	public panelJuego(Ventana ventana, Tablero tablero, int tamanio)
	{
		this.tablero=tablero;
		this.tablero.desordenar(3);
		this.tamanio=tamanio;
		this.ventana=ventana;
		this.tamanio=tamanio;
		addMouseListener( this );
		try {
        	imagen1 = ImageIO.read(new File(RUTA_IMAGEN1));
        	imagen2 = ImageIO.read(new File(RUTA_IMAGEN2));
        } catch (IOException e) {
        	e.printStackTrace();
        }

        
        repaint();
		
	}
	public void nuevoJuego(int t)
	{
		setTamanio(t);
		tablero.desordenar(t);
		
		repaint();
	}
	public int getTamanio()
	{
		return tamanio;
	}
	public void setTamanio(int t)
	{
		tamanio=t;
	}
	public void reiniciar()
	{
		tablero.reiniciar();
		repaint();
	}
	public void paint(Graphics g)
	{
		boolean [][]valores=tablero.darTablero();
		Graphics2D g2d = (Graphics2D) g;
		g2d.clearRect(0,0, this.getWidth(), this.getHeight());
		int pacingH=this.getHeight()/(tamanio);
		int pacingW=this.getWidth()/(tamanio);
		for (int i=0;i<tamanio;i++)
		{
			for (int j=0;j<tamanio;j++)
			{
				if (valores[i][j]==true)
				{
					g2d.setColor(Color.BLACK);
					g2d.fillRect(pacingW*i, pacingH*j, pacingW, pacingH);
					//g2d.drawImage(imagen1,pacingW*i,pacingH*j,null);
					
				}
				else
				{
					//g2d.drawImage(imagen2,pacingW*i,pacingH*j,null);
					g2d.setColor(Color.YELLOW);
					g2d.fillRect(pacingW*i, pacingH*j, pacingW, pacingH);
				}
				
				
			}
			
			
		}
		
	}
	
	public void mousePressed(MouseEvent e)
	{
	int click_x = e.getX();
	int click_y = e.getY();
	int[] casilla = convertirCoordenadasACasilla(click_x, click_y);
	fila=casilla[0];
	col=casilla[1];
	tablero.jugar(fila, col);
	ventana.jugar(tablero.darJugadas());
	System.out.println("mousePressed en (" + (fila+1) + ", " + (col+1) + ")");
	terminar=tablero.tableroIluminado();
	if (terminar==true)
	{
		puntaje=tablero.calcularPuntaje();
	}
	repaint();
	}
	
	private int[] convertirCoordenadasACasilla(int x, int y)
	{
	int ladoTablero = this.tamanio;
	int altoPanelTablero = getHeight();
	int anchoPanelTablero = getWidth();
	int altoCasilla = altoPanelTablero / ladoTablero;
	int anchoCasilla = anchoPanelTablero / ladoTablero;
	int fila = (int) (y / altoCasilla);
	int columna = (int) (x / anchoCasilla);
	return new int[] { fila, columna };
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method�stub
		
	}
	

}
