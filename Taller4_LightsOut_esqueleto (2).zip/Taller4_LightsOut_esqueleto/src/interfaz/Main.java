package interfaz;

import javax.swing.JPanel;

public class Main {
	
	public static void main(String[]args)
	{
		Ventana ventana= new Ventana();
		ventana.setVisible(true);
		
	}
	
	
	

}