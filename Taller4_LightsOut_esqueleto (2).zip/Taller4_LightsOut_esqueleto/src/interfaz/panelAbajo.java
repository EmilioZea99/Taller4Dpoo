package interfaz;

import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class panelAbajo extends JPanel{
	private Ventana ventana;
	private JLabel Ljugadas;
	
	public panelAbajo(Ventana ventana)
	{
		this.ventana=ventana;
		this.setLayout(new GridLayout(1,2));
		Ljugadas=new JLabel("JUGADAS: ");
		JTextField jugadador=new JTextField("JUGADOR: ");
		this.add(Ljugadas);
		this.add(jugadador);
	}
	
	public void cambiarjugadas(int j)
	{
		Ljugadas.setText("JUGADAS:�"+j);
	}
	

}