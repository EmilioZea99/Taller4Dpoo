package interfaz;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class panelArriba extends JPanel implements ActionListener{
	private Ventana ventana;
	public JRadioButton Bfacil;
	public JRadioButton Bmedio;
	public JRadioButton Bdificil;
	public int dificultad;
	public JComboBox lista;
	
	public panelArriba(Ventana ventana)
	{
		this.ventana=ventana;
		JPanel panelDificultad=new JPanel();panelDificultad.setLayout(new GridLayout(1,4));
		JPanel panelTamanio=new JPanel();panelTamanio.setLayout(new BorderLayout());
		this.add(panelTamanio,BorderLayout.WEST);
		this.add(panelDificultad,BorderLayout.EAST);
		iniciarTamanios(panelTamanio);
		iniciarDificultades(panelDificultad);
		
		
		
	}
	private void iniciarTamanios(JPanel g)
	{
		String[]tamanios= {"2x2","3x3","4x4","5x5"};
		JLabel xxx=new JLabel("TAMA�O:");
		lista= new JComboBox(tamanios);
		lista.setSelectedItem("5x5");
		g.add(lista,BorderLayout.EAST);
		g.add(xxx,BorderLayout.WEST);
		
	}
	private void iniciarDificultades(JPanel g)
	{
		JLabel xxx=new JLabel("DIFICULTADES:");
		
		Bfacil=new JRadioButton("Facil");
		Bfacil.addActionListener( this );
		
		Bmedio=new JRadioButton("Medio");
		Bmedio.addActionListener( this );
		
		Bdificil=new JRadioButton("Dificil");
		Bdificil.addActionListener( this );
		
		
		ButtonGroup botones=new ButtonGroup();
		botones.add(Bfacil);
		botones.add(Bmedio);
		botones.add(Bdificil);
		Bfacil.setSelected(true);
		g.add(xxx);g.add(Bfacil);g.add(Bmedio);g.add(Bdificil);
		
	}
	
	public int getTamanio()
	{
		if (lista.getSelectedItem().equals("2x2"))
		{
			return 2;
		}
		else if(lista.getSelectedItem().equals("3x3"))
		{
			return 3;
		}
		else if(lista.getSelectedItem().equals("4x4"))
		{
			return 4;
		}
		else
		{
			return 5;
		}
	
	}
	public int getDificultad()
	{
		return dificultad;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (Bfacil.isSelected())
		{
			dificultad=1;
		}
		else if (Bmedio.isSelected())
		{
			dificultad=5;
		}
		else if (Bdificil.isSelected())
		{
			dificultad=10;
		}
	}
}