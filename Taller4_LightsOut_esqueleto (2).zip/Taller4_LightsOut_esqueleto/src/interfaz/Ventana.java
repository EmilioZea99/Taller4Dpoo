package interfaz;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import java.awt.BorderLayout;
import interfaz.panelJuego;
import uniandes.dpoo.taller4.modelo.Tablero;

public class Ventana extends JFrame {
	private Tablero tablero;
	private int tamano;
	private int dificultad;
	private String jugador;
	private panelJuego panelJuego;
	private panelArriba panelArriba;
	private panelDerecha panelDerecha;
	private panelAbajo panelAbajo;

	public Ventana ()
	{
		this.tablero=new Tablero(5);
		this.setSize(500, 500);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setTitle("LIGHTS OUT");
		//this.setLocation(500, 200);
		//this.setBounds(500, 200, 500, 500);
		this.setLocationRelativeTo(null);
		//this.getContentPane().setBackground(Color.MAGENTA);
		this.iniciarComponentes();
	}
	
	private void iniciarComponentes()
	{
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		iniciarPanelJuego(panel);
		iniciarPanelDerecha(panel);
		iniciarPanelArriba(panel);
		iniciarPanelAbajo(panel);
		this.getContentPane().add(panel);	
		
	}
	
	private void iniciarPanelJuego(JPanel g)
	{
		//JPanel panelJuego=new JPanel();
		panelJuego panel=new panelJuego(this,this.tablero,5);
		this.panelJuego=panel;
		g.add(panel,BorderLayout.CENTER);
	}
	
	private void iniciarPanelDerecha(JPanel g)
	{
		
		panelDerecha panel=new panelDerecha(this);
		this.panelDerecha=panel;
		g.add(panel,BorderLayout.EAST);
	}
	
	private void iniciarPanelArriba(JPanel g)
	{
		
		panelArriba panelx=new panelArriba(this);
		this.panelArriba=panelx;
		g.add(panelx,BorderLayout.NORTH);
		
	}
	
	
	private void iniciarPanelAbajo(JPanel g)
	{
		panelAbajo panelAbajo=new panelAbajo(this);
		this.panelAbajo=panelAbajo;
		g.add(panelAbajo,BorderLayout.SOUTH);
	}
	
	public void nuevoJuego()
	{
		int dificultad=panelArriba.getDificultad();
		int tamano=panelArriba.getTamanio();
		this.tablero=new Tablero(tamano);
		this.tablero.desordenar(dificultad);
		panelJuego.nuevoJuego(tamano);
	}
	public void jugar(int jugadas)
	{
		
		this.panelAbajo.cambiarjugadas(jugadas);
	}
	public void terminar()
	{
		
	}
	
	public void reiniciar()
	{
		this.panelJuego.reiniciar();
		this.panelAbajo.cambiarjugadas(0);
	}
	
	
	
}